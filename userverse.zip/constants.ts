import { SocialPlatform } from './types';
import { TwitterIcon, FacebookIcon, LinkedInIcon, InstagramIcon, YoutubeIcon, KickIcon, TwitchIcon, TikTokIcon } from './components/IconComponents';

export const SOCIAL_MEDIA_PLATFORMS: SocialPlatform[] = [
  {
    id: 'twitter',
    name: 'Twitter / X',
    url: 'https://twitter.com/signup',
    Icon: TwitterIcon,
    color: 'bg-sky-500',
    textColor: 'text-sky-500',
    characterLimits: { bio: 160, handle: 15 },
    exampleFields: [
      { label: 'Username/Handle', profileKey: 'handle', commonSelectors: ['input[name="text"]', 'input[data-testid="UserName"]', 'input[aria-label*="Username"]'] , notes: "Often labeled 'Username' during signup/edit."},
      { label: 'Display Name', profileKey: 'name', commonSelectors: ['input[name="name"]', 'input[data-testid="DisplayName"]'], notes: "Your public name."},
      { label: 'Bio/Description', profileKey: 'bio', commonSelectors: ['textarea[name="description"]', 'textarea[data-testid="UserDescription"]', 'textarea[aria-label*="Bio"]'], notes: "Your profile description."},
      { label: 'Website', profileKey: 'photoUrl', commonSelectors: ['input[name="url"]', 'input[data-testid="UserUrl"]'], notes: "Use your photo URL here if no dedicated website field, or your actual website."},
    ]
  },
  {
    id: 'facebook',
    name: 'Facebook',
    url: 'https://www.facebook.com/r.php', 
    Icon: FacebookIcon,
    color: 'bg-blue-600',
    textColor: 'text-blue-600',
    characterLimits: { bio: 101 }, 
    exampleFields: [
      { label: 'Name', profileKey: 'name', commonSelectors: ['input[name="firstname"]', 'input[name="lastname"]', 'input[aria-label*="Name"]'] , notes: "Facebook uses first and last names separately."},
      { label: 'Bio/Intro', profileKey: 'bio', commonSelectors: ['textarea[name="bio"]', 'textarea[placeholder*="Describe who you are"]'], notes: "Short intro text."},
    ]
  },
  {
    id: 'linkedin',
    name: 'LinkedIn',
    url: 'https://www.linkedin.com/signup/cold-join', 
    Icon: LinkedInIcon,
    color: 'bg-sky-700',
    textColor: 'text-sky-700',
    characterLimits: { bio: 2600 }, 
    exampleFields: [
      { label: 'Headline', profileKey: 'handle', commonSelectors: ['input[name="headline"]'], notes: "Use your preferred handle or a short title here."},
      { label: 'Full Name', profileKey: 'name', commonSelectors: ['input[id*="firstName"]', 'input[id*="lastName"]'], notes: "LinkedIn uses first and last names."},
      { label: 'Summary/About', profileKey: 'bio', commonSelectors: ['textarea[id*="summary"]', 'textarea[aria-label*="Summary"]'], notes: "The 'About' section."},
    ]
  },
  {
    id: 'instagram',
    name: 'Instagram',
    url: 'https://www.instagram.com/accounts/emailsignup/', 
    Icon: InstagramIcon,
    color: 'bg-pink-500',
    textColor: 'text-pink-500',
    characterLimits: { bio: 150, handle: 30 },
    exampleFields: [
        { label: 'Username', profileKey: 'handle', commonSelectors: ['input[name="username"]'], notes: "Your Instagram handle."},
        { label: 'Name', profileKey: 'name', commonSelectors: ['input[name="fullName"]'], notes: "Your display name."},
        { label: 'Bio', profileKey: 'bio', commonSelectors: ['textarea[id*="biography"]', 'textarea[aria-label*="Bio"]'], notes: "Your Instagram bio."},
        { label: 'Website', profileKey: 'photoUrl', commonSelectors: ['input[name="website"]'], notes: "Profile website link. Can use photo URL as placeholder."},
    ]
  },
   {
    id: 'youtube',
    name: 'YouTube',
    url: 'https://accounts.google.com/signup', 
    Icon: YoutubeIcon,
    color: 'bg-red-600',
    textColor: 'text-red-600',
    characterLimits: { bio: 1000, handle: 30 }, 
    exampleFields: [
        { label: 'Channel Name', profileKey: 'name', commonSelectors: ['input[aria-label*="Channel name"]', 'yt-formatted-string[title*="Channel name"] + input'], notes: "Your channel's name."},
        { label: 'Handle', profileKey: 'handle', commonSelectors: ['input[name="handle"]', 'input[aria-label*="Handle"]'], notes: "Your YouTube @handle."},
        { label: 'Description', profileKey: 'bio', commonSelectors: ['textarea[name="description"]', 'textarea[aria-label*="Description"]', '#description'], notes: "Channel description."},
    ]
  },
  {
    id: 'kick',
    name: 'Kick',
    url: 'https://kick.com/signup',
    Icon: KickIcon,
    color: 'bg-green-500',
    textColor: 'text-green-500',
    characterLimits: { bio: 300, handle: 25 }, // Approximate
    exampleFields: [
        { label: 'Username', profileKey: 'handle', commonSelectors: ['input[name="username"]', 'input[id="username"]'], notes: "Your Kick username."},
        { label: 'Display Name', profileKey: 'name', commonSelectors: ['input[name="displayName"]', 'input[id="displayName"]'], notes: "Your Kick display name (if different from username)."},
        { label: 'About', profileKey: 'bio', commonSelectors: ['textarea[name="description"]', 'textarea[id="description"]'], notes: "Your Kick channel's 'About' section."},
    ]
  },
  {
    id: 'twitch',
    name: 'Twitch',
    url: 'https://www.twitch.tv/signup',
    Icon: TwitchIcon,
    color: 'bg-purple-600',
    textColor: 'text-purple-600',
    characterLimits: { bio: 300, handle: 25 }, // Username: 4-25, Bio: max 300
    exampleFields: [
        { label: 'Username', profileKey: 'handle', commonSelectors: ['input[id="signup-username"]', 'input[autocomplete="username"]'], notes: "Your Twitch username."},
        { label: 'Display Name', profileKey: 'name', commonSelectors: ['input[data-a-target="DisplayNameInput"]', 'input[aria-label*="Display Name"]'], notes: "Your Twitch display name. Case can differ from username."},
        { label: 'Bio', profileKey: 'bio', commonSelectors: ['textarea[data-a-target="profile-bio-input"]', 'textarea[placeholder*="Tell viewers about yourself"]'], notes: "Your Twitch profile bio."},
    ]
  },
  {
    id: 'tiktok',
    name: 'TikTok',
    url: 'https://www.tiktok.com/signup/phone-or-email',
    Icon: TikTokIcon,
    color: 'bg-pink-600', // Using one of TikTok's vibrant accent colors
    textColor: 'text-pink-600',
    characterLimits: { bio: 80, handle: 24 }, // Handle 2-24 chars
    exampleFields: [
        { label: 'Username', profileKey: 'handle', commonSelectors: ['input[name="username"]'], notes: "Your TikTok username (unique, no spaces)."},
        { label: 'Name', profileKey: 'name', commonSelectors: ['input[name="nickname"]', 'input[placeholder*="Name"]'], notes: "Your TikTok profile name (can include spaces, emojis)."},
        { label: 'Bio', profileKey: 'bio', commonSelectors: ['textarea[placeholder*="Bio"]', 'textarea[data-e2e="bio-input"]'], notes: "Your TikTok bio."},
    ]
  },
];

export const API_KEY_MESSAGE = "Gemini API Key (process.env.API_KEY) is not configured. Suggestions feature will be unavailable.";
