
import React, { useState } from 'react';
import { UserProfile } from '../types';
import { UserCircleIcon, AtSymbolIcon, DocumentTextIcon, PhotoIcon } from './IconComponents';

interface ProfileInputFormProps {
  onProfileSubmit: (profile: UserProfile) => void;
  initialProfile?: UserProfile;
}

const ProfileInputForm: React.FC<ProfileInputFormProps> = ({ onProfileSubmit, initialProfile }) => {
  const [profile, setProfile] = useState<UserProfile>(initialProfile || {
    name: '',
    handle: '',
    bio: '',
    photoUrl: '',
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setProfile(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (profile.name && profile.handle && profile.bio) {
      onProfileSubmit(profile);
    } else {
      alert("Please fill in Name, Handle, and Bio.");
    }
  };

  return (
    <div className="bg-indigo-900 p-6 md:p-8 rounded-xl shadow-2xl w-full max-w-lg mx-auto">
      <h2 className="text-3xl font-bold mb-6 text-center text-fuchsia-400">Your Base Profile</h2>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-slate-300 mb-1">Full Name</label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <UserCircleIcon className="h-5 w-5 text-slate-500" />
            </div>
            <input
              type="text"
              name="name"
              id="name"
              value={profile.name}
              onChange={handleChange}
              placeholder="e.g., Ada Lovelace"
              className="w-full pl-10 pr-3 py-2 bg-indigo-800 border border-purple-700 rounded-md shadow-sm focus:ring-fuchsia-500 focus:border-fuchsia-500 text-slate-100 placeholder-slate-500"
              required
            />
          </div>
        </div>
        <div>
          <label htmlFor="handle" className="block text-sm font-medium text-slate-300 mb-1">Preferred Handle</label>
          <div className="relative">
             <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <AtSymbolIcon className="h-5 w-5 text-slate-500" />
            </div>
            <input
              type="text"
              name="handle"
              id="handle"
              value={profile.handle}
              onChange={handleChange}
              placeholder="e.g., adalovescoding"
              className="w-full pl-10 pr-3 py-2 bg-indigo-800 border border-purple-700 rounded-md shadow-sm focus:ring-fuchsia-500 focus:border-fuchsia-500 text-slate-100 placeholder-slate-500"
              required
            />
          </div>
        </div>
        <div>
          <label htmlFor="bio" className="block text-sm font-medium text-slate-300 mb-1">Short Bio</label>
           <div className="relative">
            <div className="absolute top-3 left-0 pl-3 flex items-start pointer-events-none">
                <DocumentTextIcon className="h-5 w-5 text-slate-500" />
            </div>
            <textarea
              name="bio"
              id="bio"
              value={profile.bio}
              onChange={handleChange}
              rows={4}
              placeholder="Tell us about yourself, your passions, and what you do."
              className="w-full pl-10 pr-3 py-2 bg-indigo-800 border border-purple-700 rounded-md shadow-sm focus:ring-fuchsia-500 focus:border-fuchsia-500 text-slate-100 placeholder-slate-500"
              required
            />
          </div>
        </div>
        <div>
          <label htmlFor="photoUrl" className="block text-sm font-medium text-slate-300 mb-1">Profile Photo URL or Description</label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <PhotoIcon className="h-5 w-5 text-slate-500" />
            </div>
            <input
              type="text"
              name="photoUrl"
              id="photoUrl"
              value={profile.photoUrl}
              onChange={handleChange}
              placeholder="https://example.com/photo.jpg or 'A friendly golden retriever'"
              className="w-full pl-10 pr-3 py-2 bg-indigo-800 border border-purple-700 rounded-md shadow-sm focus:ring-fuchsia-500 focus:border-fuchsia-500 text-slate-100 placeholder-slate-500"
            />
          </div>
           <p className="mt-1 text-xs text-slate-400">Enter a URL to an image, or describe the kind of photo you'd use.</p>
        </div>
        <button
          type="submit"
          className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-fuchsia-600 hover:bg-fuchsia-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-indigo-900 focus:ring-fuchsia-500 transition-colors"
        >
          Save Profile & Continue
        </button>
      </form>
    </div>
  );
};

export default ProfileInputForm;
