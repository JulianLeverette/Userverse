
import React from 'react';
import { SocialPlatform, UserProfile } from '../types';
import Modal from './Modal';

interface DataExporterModalProps {
  isOpen: boolean;
  onClose: () => void;
  platform: SocialPlatform | null;
  userProfile: UserProfile | null;
}

const DataExporterModal: React.FC<DataExporterModalProps> = ({ isOpen, onClose, platform, userProfile }) => {
  if (!platform || !userProfile) return null;

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      alert('Copied to clipboard!');
    }).catch(err => {
      console.error('Failed to copy: ', err);
      alert('Failed to copy to clipboard.');
    });
  };
  
  const generateSnippet = (label: string, value: string, selectors: string[], notes?: string) => {
    const selectorString = selectors.map(s => `document.querySelector('${s}')`).join(' || ');
    const fullSnippet = `// For ${label} on ${platform.name}\n// Note: ${notes || 'Verify selector in browser dev tools.'}\nconst field = ${selectorString};\nif (field) { field.value = \`${value.replace(/`/g, '\\`')}\`; console.log('${label} field updated.'); } else { console.warn('Could not find field for ${label} with suggested selectors.'); }`;

    return (
      <div className="mb-4">
        <p className="text-sm font-medium text-slate-300">JavaScript for <span className="font-semibold text-fuchsia-300">{label}</span>:</p>
        {notes && <p className="text-xs text-slate-400 mb-1">{notes}</p>}
        <div className="bg-indigo-950 p-3 rounded-md relative group">
          <pre className="text-xs text-green-300 whitespace-pre-wrap break-all">
            <code>{fullSnippet}</code>
          </pre>
          <button
            onClick={() => copyToClipboard(fullSnippet)}
            className="absolute top-2 right-2 px-2 py-1 bg-fuchsia-600 text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity"
          >
            Copy
          </button>
        </div>
      </div>
    );
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`Export Data for ${platform.name}`}>
      <div className="space-y-6">
        <div>
          <h4 className="text-lg font-semibold text-fuchsia-300 mb-2">Your Profile Data:</h4>
          <div className="bg-indigo-800 p-4 rounded-lg space-y-1">
            <p><strong>Name:</strong> <span className="text-slate-200">{userProfile.name}</span></p>
            <p><strong>Handle:</strong> <span className="text-slate-200">{userProfile.handle}</span></p>
            <p><strong>Bio:</strong> <span className="text-slate-200">{userProfile.bio}</span></p>
            <p><strong>Photo URL/Desc:</strong> <span className="text-slate-200">{userProfile.photoUrl}</span></p>
          </div>
        </div>

        <div>
          <h4 className="text-lg font-semibold text-fuchsia-300 mb-2">Example JavaScript Snippets:</h4>
          <p className="text-sm text-slate-400 mb-3">
            Copy these snippets and paste them into your browser's developer console on the respective platform's profile editing page.
            <strong className="text-amber-400"> Always review code before running it in your browser. Selectors might need adjustment.</strong>
          </p>
          {platform.exampleFields.map(field => {
             let valueToUse = '';
             if (field.profileKey === 'suggestedHandle') valueToUse = userProfile.handle; 
             else if (field.profileKey === 'suggestedBio') valueToUse = userProfile.bio; 
             else valueToUse = userProfile[field.profileKey as keyof UserProfile] || '';

             return generateSnippet(field.label, valueToUse, field.commonSelectors, field.notes);
          })}
        </div>
      </div>
    </Modal>
  );
};

export default DataExporterModal;
