
import React from 'react';
import { SocialPlatform, SuggestedProfileVariation } from '../types';
import Modal from './Modal';
import LoadingSpinner from './LoadingSpinner';
import { SparklesIcon } from './IconComponents';

interface SuggestionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  platform: SocialPlatform | null;
  suggestions: SuggestedProfileVariation[] | null;
  isLoading: boolean;
  error: string | null;
}

const SuggestionsModal: React.FC<SuggestionsModalProps> = ({ isOpen, onClose, platform, suggestions, isLoading, error }) => {
  if (!platform) return null;

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`💡 Suggestions for ${platform.name}`}>
      {isLoading && (
        <div className="flex flex-col items-center justify-center h-40">
          <LoadingSpinner size="h-12 w-12" />
          <p className="mt-4 text-slate-300">Generating suggestions with Gemini...</p>
        </div>
      )}
      {error && <p className="text-red-400 bg-red-900 p-3 rounded-md">Error: {error}</p>}
      {!isLoading && !error && suggestions && suggestions.length > 0 && (
        <div className="space-y-6">
          {suggestions.map((suggestion, index) => (
            <div key={index} className="bg-indigo-800 p-4 rounded-lg shadow">
              <h4 className="text-lg font-semibold text-fuchsia-300 mb-2 flex items-center">
                <SparklesIcon className="h-5 w-5 mr-2 text-yellow-400" />
                Option {index + 1}
              </h4>
              <p className="text-sm text-slate-400 mb-1"><strong>Handle:</strong> <span className="text-slate-200">{suggestion.handle}</span></p>
              <p className="text-sm text-slate-400 mb-1"><strong>Bio:</strong> <span className="text-slate-200">{suggestion.bio}</span></p>
              {suggestion.hashtags && suggestion.hashtags.length > 0 && (
                <p className="text-sm text-slate-400 mb-1">
                  <strong>Hashtags:</strong>{' '}
                  {suggestion.hashtags.map(tag => (
                    <span key={tag} className="inline-block bg-purple-700 text-fuchsia-300 px-2 py-0.5 rounded-full text-xs mr-1 mb-1">{tag}</span>
                  ))}
                </p>
              )}
              <p className="text-sm text-slate-400"><strong>Photo Tip:</strong> <span className="text-slate-200">{suggestion.photoTip}</span></p>
            </div>
          ))}
        </div>
      )}
      {!isLoading && !error && (!suggestions || suggestions.length === 0) && (
        <p className="text-slate-400">No suggestions available at the moment.</p>
      )}
    </Modal>
  );
};

export default SuggestionsModal;
