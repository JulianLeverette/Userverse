
import React from 'react';
import { SocialPlatform, UserProfile } from '../types';
import { LightBulbIcon, CheckCircleIcon } from './IconComponents'; 

interface SocialMediaPlatformCardProps {
  platform: SocialPlatform;
  userProfile: UserProfile | null;
  isDone: boolean;
  onToggleDone: (platformId: string) => void;
  onGetSuggestions: (platform: SocialPlatform) => void;
  isApiKeyMissing: boolean;
}

const SocialMediaPlatformCard: React.FC<SocialMediaPlatformCardProps> = ({
  platform,
  userProfile,
  isDone,
  onToggleDone,
  onGetSuggestions,
  isApiKeyMissing
}) => {
  const PlatformIcon = platform.Icon;

  return (
    <div className={`bg-indigo-900 rounded-xl shadow-xl p-6 flex flex-col justify-between transition-all duration-300 hover:shadow-2xl hover:scale-105 border-2 ${isDone ? 'border-green-500' : 'border-purple-700'}`}>
      <div>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <PlatformIcon className={`h-10 w-10 mr-3 fill-current ${platform.textColor.replace('text-','fill-')}`} />
            <a
              href={platform.url}
              target="_blank"
              rel="noopener noreferrer"
              className={`text-2xl font-bold ${platform.textColor} hover:underline`}
              aria-label={`Visit ${platform.name} homepage (opens in new tab)`}
            >
              {platform.name}
            </a>
          </div>
          {isDone && <CheckCircleIcon className="h-7 w-7 text-green-500" />}
        </div>
        <p className="text-sm text-slate-400 mb-1">
          {platform.characterLimits?.bio ? `Bio Limit: ${platform.characterLimits.bio} chars. ` : ''}
          {platform.characterLimits?.handle ? `Handle Limit: ${platform.characterLimits.handle} chars.` : ''}
        </p>
      </div>
      
      <div className="mt-6 space-y-3">
        <button
          onClick={() => onGetSuggestions(platform)}
          disabled={!userProfile || isApiKeyMissing}
          className={`w-full flex items-center justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-fuchsia-600 hover:bg-fuchsia-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-indigo-900 focus:ring-fuchsia-500 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed`}
          title={isApiKeyMissing ? "API Key not configured for suggestions" : "Get profile suggestions"}
        >
          <LightBulbIcon className="h-5 w-5 mr-2" />
          Get Suggestions
        </button>
        
        <a
          href={platform.url}
          target="_blank"
          rel="noopener noreferrer"
          className={`w-full flex items-center justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white ${platform.color} hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-indigo-900 ${platform.textColor.replace('text-','ring-')} transition-all`}
          aria-label={`Get started with ${platform.name} (opens in new tab)`}
        >
          <PlatformIcon className="h-5 w-5 mr-2 fill-current text-white" />
          Get Started
        </a>

        <button
          onClick={() => onToggleDone(platform.id)}
          className={`w-full px-4 py-2 border rounded-md shadow-sm text-sm font-medium transition-colors
            ${isDone 
              ? 'bg-green-600 hover:bg-green-700 border-green-500 text-white' 
              : 'bg-purple-700 hover:bg-purple-600 border-purple-600 text-slate-100'}`}
        >
          {isDone ? 'Mark as Not Done' : 'Mark as Done'}
        </button>
      </div>
    </div>
  );
};

export default SocialMediaPlatformCard;
