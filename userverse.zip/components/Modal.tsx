
import React from 'react';
import { XCircleIcon } from './IconComponents';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
}

const Modal: React.FC<ModalProps> = ({ isOpen, onClose, title, children }) => {
  if (!isOpen) return null;

  const css = `
    @keyframes modalFadeIn {
      to {
        opacity: 1;
        transform: scale(1);
      }
    }
    .animate-modalFadeIn {
      animation: modalFadeIn 0.3s forwards;
    }
  `;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-50 transition-opacity duration-300 ease-in-out">
      <div className="bg-indigo-900 rounded-lg shadow-xl p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto transform transition-all duration-300 ease-in-out scale-95 opacity-0 animate-modalFadeIn">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-2xl font-semibold text-fuchsia-400">{title}</h3>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 transition-colors"
            aria-label="Close modal"
          >
            <XCircleIcon className="h-8 w-8" />
          </button>
        </div>
        <div>{children}</div>
      </div>
      <style dangerouslySetInnerHTML={{ __html: css }} />
    </div>
  );
};

export default Modal;
