import React, { useState, useEffect, useCallback } from 'react';
import { UserProfile, SocialPlatform, PlatformProgress, SuggestedProfileVariation, ModalType } from './types';
import { SOCIAL_MEDIA_PLATFORMS, API_KEY_MESSAGE } from './constants';
import ProfileInputForm from './components/ProfileInputForm';
import SocialMediaPlatformCard from './components/SocialMediaPlatformCard';
import SuggestionsModal from './components/SuggestionsModal';
import DataExporterModal from './components/DataExporterModal';
import { getProfileSuggestions } from './services/geminiService';
import { SparklesIcon } from './components/IconComponents';

const App: React.FC = () => {
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [platformProgress, setPlatformProgress] = useState<PlatformProgress>({});
  
  const [activeModal, setActiveModal] = useState<ModalType>(ModalType.NONE);
  const [selectedPlatform, setSelectedPlatform] = useState<SocialPlatform | null>(null);
  
  const [suggestions, setSuggestions] = useState<SuggestedProfileVariation[] | null>(null);
  const [isFetchingSuggestions, setIsFetchingSuggestions] = useState<boolean>(false);
  const [suggestionError, setSuggestionError] = useState<string | null>(null);
  
  const [isApiKeyMissing, setIsApiKeyMissing] = useState<boolean>(false);

  const handleProfileSubmit = (profile: UserProfile) => {
    setUserProfile(profile);
  };

  const handleToggleDone = (platformId: string) => {
    setPlatformProgress(prev => ({
      ...prev,
      [platformId]: prev[platformId] === 'done' ? 'pending' : 'done',
    }));
  };

  const handleGetSuggestions = useCallback(async (platform: SocialPlatform) => {
    setIsFetchingSuggestions(true);
    setSuggestionError(null);
    setSuggestions(null); // Clear previous suggestions
    setActiveModal(ModalType.SUGGESTIONS);
    setSelectedPlatform(platform);

    if (isApiKeyMissing) {
      setSuggestionError(API_KEY_MESSAGE);
      setIsFetchingSuggestions(false);
      return;
    }

    if (!userProfile) {
        setSuggestionError("User profile is not set.");
        setIsFetchingSuggestions(false);
        return;
    }

    try {
      const result = await getProfileSuggestions(userProfile, platform);
      if (result && result.suggestions) {
        setSuggestions(result.suggestions);
      } else {
        setSuggestionError("No suggestions returned or unexpected format.");
      }
    } catch (error) {
      console.error(error);
      setSuggestionError(error instanceof Error ? error.message : "Failed to fetch suggestions.");
    } finally {
      setIsFetchingSuggestions(false);
    }
  }, [userProfile, isApiKeyMissing]);

  // handleExportData is kept in case the DataExporterModal is used in another way later
  const handleExportData = useCallback((platform: SocialPlatform) => {
    setSelectedPlatform(platform);
    setActiveModal(ModalType.EXPORTER);
  }, []);

  const handleCloseModal = () => {
    setActiveModal(ModalType.NONE);
    setSelectedPlatform(null);
    setSuggestions(null);
    setSuggestionError(null);
  };

  useEffect(() => {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
      console.warn(API_KEY_MESSAGE);
      setIsApiKeyMissing(true);
    } else {
      setIsApiKeyMissing(false);
    }
  }, []);
  
  useEffect(() => {
    const initialProgress = SOCIAL_MEDIA_PLATFORMS.reduce((acc, platform) => {
      acc[platform.id] = 'pending';
      return acc;
    }, {} as PlatformProgress);
    setPlatformProgress(initialProgress);
  }, []);


  if (!userProfile) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-slate-950 bg-[radial-gradient(ellipse_at_top,rgba(88,28,135,0.5)_0%,rgba(67,56,202,0.3)_40%,transparent_80%)]">
        <header className="mb-10 text-center">
            {/* Logo removed */}
            <h1 className="text-5xl md:text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-fuchsia-500 to-pink-500 mb-2 mt-8 md:mt-0">
                Userverse
            </h1>
            <p className="text-slate-300 text-lg">Your AI-powered assistant for a stellar social media presence!</p>
        </header>
        <ProfileInputForm onProfileSubmit={handleProfileSubmit} />
        {isApiKeyMissing && (
          <div className="mt-8 p-4 bg-amber-700 text-amber-100 rounded-md shadow-lg max-w-lg text-center">
            <strong>Warning:</strong> {API_KEY_MESSAGE} Some features like AI suggestions will be unavailable.
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8 bg-slate-950 bg-[radial-gradient(ellipse_at_top,rgba(88,28,135,0.5)_0%,rgba(67,56,202,0.3)_40%,transparent_80%)]">
      <header className="mb-10 text-center">
        {/* Logo removed */}
        <h1 className="text-5xl md:text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-fuchsia-500 to-pink-500 mb-2 mt-8 md:mt-0">
            Userverse
        </h1>
        <p className="text-slate-300 text-lg">Welcome back, {userProfile.name}! Let's optimize your profiles.</p>
        <button 
          onClick={() => setUserProfile(null)}
          className="mt-4 px-4 py-2 bg-fuchsia-600 hover:bg-fuchsia-700 text-white rounded-md text-sm transition-colors"
        >
          Edit Base Profile
        </button>
        {isApiKeyMissing && (
          <div className="mt-4 p-3 bg-amber-800 text-amber-200 rounded-md shadow-md max-w-xl mx-auto text-sm">
            <strong>Warning:</strong> {API_KEY_MESSAGE} AI suggestions are unavailable.
          </div>
        )}
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
        {SOCIAL_MEDIA_PLATFORMS.map(platform => (
          <SocialMediaPlatformCard
            key={platform.id}
            platform={platform}
            userProfile={userProfile}
            isDone={platformProgress[platform.id] === 'done'}
            onToggleDone={handleToggleDone}
            onGetSuggestions={handleGetSuggestions}
            isApiKeyMissing={isApiKeyMissing}
          />
        ))}
      </div>

      <SuggestionsModal
        isOpen={activeModal === ModalType.SUGGESTIONS}
        onClose={handleCloseModal}
        platform={selectedPlatform}
        suggestions={suggestions}
        isLoading={isFetchingSuggestions}
        error={suggestionError}
      />

      <DataExporterModal
        isOpen={activeModal === ModalType.EXPORTER}
        onClose={handleCloseModal}
        platform={selectedPlatform}
        userProfile={userProfile}
      />
      <footer className="text-center mt-12 py-6 border-t border-purple-800/50">
        <p className="text-slate-400 text-sm">
            Userverse - Powered by AI <SparklesIcon className="inline h-4 w-4 text-yellow-400" />
        </p>
      </footer>
    </div>
  );
};

export default App;