
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { UserProfile, SocialPlatform, GeminiSuggestionsResponse } from '../types';

const API_KEY = process.env.API_KEY;

let ai: GoogleGenAI | null = null;
if (API_KEY) {
  ai = new GoogleGenAI({ apiKey: API_KEY });
}

function constructPrompt(profile: UserProfile, platform: SocialPlatform): string {
  let prompt = `You are an expert social media profile advisor.
Given the user's base profile:
Name: ${profile.name}
Preferred Handle: ${profile.handle}
Bio: ${profile.bio}
Photo URL/Description: ${profile.photoUrl}

And the target platform: ${platform.name}
Platform specific constraints (if any):
${platform.characterLimits?.handle ? `- Handle max length: ${platform.characterLimits.handle} characters` : ''}
${platform.characterLimits?.bio ? `- Bio max length: ${platform.characterLimits.bio} characters` : ''}

Suggest 2-3 tailored variations for their profile on ${platform.name}. For each variation, provide:
1. A suitable handle/username (considering platform constraints and user's preference). Ensure it's concise and catchy.
2. A bio (observe character limits for ${platform.name}). Make it engaging and platform-appropriate.
3. 3-5 relevant hashtags or keywords (as an array of strings).
4. A brief suggestion on how their photo (from the URL/description) could be presented or if a different style might be better for ${platform.name}.

Return the suggestions as a VALID JSON object with a key "suggestions", which is an array of objects. Each object in the array MUST have keys: "handle" (string), "bio" (string), "hashtags" (array of strings), and "photoTip" (string).
Do not include any text outside the JSON object.
Example for Twitter:
Base Bio: "Software engineer passionate about AI and web development. Loves hiking and photography."
Response for Twitter (should be actual JSON, no markdown):
{
  "suggestions": [
    {
      "handle": "${profile.handle}Dev",
      "bio": "AI & Web Dev enthusiast. Building cool things with code. 📸 Hiker. #Tech #AI #WebDevelopment",
      "hashtags": ["#Tech", "#AI", "#WebDevelopment", "#SoftwareEngineer"],
      "photoTip": "A professional yet approachable headshot works well on Twitter. Consider one with good lighting."
    }
  ]
}`;
  return prompt;
}

export const getProfileSuggestions = async (
  profile: UserProfile,
  platform: SocialPlatform
): Promise<GeminiSuggestionsResponse | null> => {
  if (!ai) {
    console.error("Gemini API client not initialized. API_KEY might be missing.");
    throw new Error("API client not initialized. Check API_KEY.");
  }

  const model = 'gemini-2.5-flash-preview-04-17';
  const prompt = constructPrompt(profile, platform);

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
        model: model,
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            temperature: 0.7, // Add some creativity
        }
    });
    
    let jsonStr = response.text.trim();
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
      jsonStr = match[2].trim();
    }

    const parsedData = JSON.parse(jsonStr) as GeminiSuggestionsResponse;
    if (parsedData && parsedData.suggestions) {
        return parsedData;
    }
    console.error("Parsed data is not in expected format:", parsedData);
    return null;

  } catch (error) {
    console.error('Error fetching suggestions from Gemini API:', error);
    throw error; // Re-throw to be caught by the calling component
  }
};
    