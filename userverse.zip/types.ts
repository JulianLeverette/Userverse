
import React from 'react';

export interface UserProfile {
  name: string;
  handle: string;
  bio: string;
  photoUrl: string;
}

export interface SocialPlatformExampleField {
  label: string;
  profileKey: keyof UserProfile | 'suggestedHandle' | 'suggestedBio';
  commonSelectors: string[];
  notes?: string;
}

export interface SocialPlatform {
  id: string;
  name: string;
  url: string;
  Icon: React.FC<React.SVGProps<SVGSVGElement>>;
  color: string; // Tailwind bg color class e.g. bg-blue-500
  textColor: string; // Tailwind text color class e.g. text-blue-500
  characterLimits?: {
    bio?: number;
    handle?: number;
  };
  exampleFields: SocialPlatformExampleField[];
}

export interface SuggestedProfileVariation {
  handle: string;
  bio: string;
  hashtags: string[];
  photoTip: string;
}

export interface GeminiSuggestionsResponse {
  suggestions: SuggestedProfileVariation[];
}

export type PlatformProgress = Record<string, 'pending' | 'done'>;

export enum ModalType {
  NONE,
  SUGGESTIONS,
  EXPORTER
}
    